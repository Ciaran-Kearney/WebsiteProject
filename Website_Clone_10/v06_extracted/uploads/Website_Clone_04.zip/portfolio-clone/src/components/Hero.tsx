"use client";

import Image from "next/image";
import { motion } from "framer-motion";

export default function Hero() {
  return (
    <section className="min-h-screen pt-28 pb-20 flex flex-col justify-center relative overflow-hidden">
      <div className="container mx-auto px-4 md:px-6 z-10">
        <div className="flex flex-col md:flex-row items-center gap-10">
          <div className="flex-1">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-2">
                Hi, I'm <span className="text-portfolio-purple">Ciarán</span> 👋
              </h1>
              <p className="text-xl text-portfolio-grey mb-6">
                (I'm a <span className="text-portfolio-purple">Mechanical Engineer</span>)
              </p>
              <p className="text-lg mb-10 max-w-xl">
                Welcome to my portfolio, please view on desktop for an interactive experience!
              </p>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
              className="hidden md:block"
            >
              <div className="relative w-full max-w-2xl h-64 bg-portfolio-darkNavy rounded-lg p-4 shadow-xl">
                <div className="absolute top-0 left-0 w-full p-2 bg-portfolio-navy rounded-t-lg flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <div className="w-3 h-3 rounded-full bg-yellow-500" />
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                </div>
                <div className="mt-6 grid grid-cols-2 gap-4">
                  <div className="bg-portfolio-navy rounded-md p-3 h-48">
                    <div className="w-full h-5 bg-portfolio-grey/20 rounded mb-2" />
                    <div className="w-3/4 h-5 bg-portfolio-grey/20 rounded mb-2" />
                    <div className="w-1/2 h-5 bg-portfolio-grey/20 rounded mb-4" />
                    <div className="w-full h-20 bg-portfolio-grey/10 rounded" />
                  </div>
                  <div className="bg-portfolio-navy rounded-md p-3 h-48">
                    <div className="w-full h-5 bg-portfolio-grey/20 rounded mb-2" />
                    <div className="w-2/3 h-5 bg-portfolio-grey/20 rounded mb-2" />
                    <div className="w-3/4 h-5 bg-portfolio-grey/20 rounded mb-4" />
                    <div className="w-full h-20 bg-portfolio-grey/10 rounded" />
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.5, delay: 0.1 }}
            className="flex-shrink-0"
          >
            <div className="relative w-40 h-40 md:w-60 md:h-60 rounded-full overflow-hidden border-4 border-portfolio-purple">
              <div className="w-full h-full bg-portfolio-grey/20 flex items-center justify-center text-portfolio-purple">
                <span className="text-sm">Profile Image</span>
              </div>
            </div>
            <div className="mt-4 flex justify-center gap-2">
              <a
                href="#contact"
                className="bg-portfolio-purple text-white px-4 py-2 rounded-md text-sm hover:bg-portfolio-lightPurple transition-colors"
              >
                Contact me
              </a>
              <a
                href="#about"
                className="bg-portfolio-darkNavy text-portfolio-text px-4 py-2 rounded-md text-sm hover:bg-portfolio-grey/40 transition-colors"
              >
                About
              </a>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Background gradient */}
      <div className="absolute bottom-0 left-0 w-full h-1/2 bg-gradient-to-t from-portfolio-navy/80 to-transparent z-0" />
    </section>
  );
}
